#ifndef __UTILS_H
#define __UTILS_H

#include "circom.hpp"

std::string int_to_hex( u64 i );
u64 fnv1a(std::string s);


#endif // __UTILS_H
